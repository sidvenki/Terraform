# Support

Terraform is a mature project with a growing community. There are active, dedicated people willing to help you through various mediums.

Take a look at those mediums listed at https://www.terraform.io/community.html
